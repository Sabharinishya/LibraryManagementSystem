package com.ey.exception;

public class CopyNotFoundException extends RuntimeException {
	public CopyNotFoundException(String message) {
		super(message);
	}
}