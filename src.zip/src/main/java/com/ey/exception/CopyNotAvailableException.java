package com.ey.exception;

public class CopyNotAvailableException extends RuntimeException {
	public CopyNotAvailableException(String message) {
		super(message);
	}
}
