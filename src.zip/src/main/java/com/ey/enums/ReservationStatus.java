package com.ey.enums;

public enum ReservationStatus {
PENDING,
APPROVED,
CANCELLED,
FULFILLED
}
