package com.ey.enums;

public enum UserStatus {
ACTIVE,
INACTIVE
}
