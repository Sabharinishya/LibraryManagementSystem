package com.ey.enums;

public enum LoanStatus {
ISSUED,
RETURNED,
OVERDUE,
ACTIVE
}
