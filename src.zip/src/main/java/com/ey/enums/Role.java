package com.ey.enums;

public enum Role {
ADMIN,
READER,
LIBRARIAN
}
