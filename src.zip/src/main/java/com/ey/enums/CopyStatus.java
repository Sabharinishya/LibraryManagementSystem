package com.ey.enums;

public enum CopyStatus {
AVAILABLE,
ON_LOAN,
RESERVED,
LOST,
ISSUED
}
